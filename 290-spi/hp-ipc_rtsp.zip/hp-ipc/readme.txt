put directory hp-ipc into sdk.../mpp/sample/
cd hp-ipc
make 
