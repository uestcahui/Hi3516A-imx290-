#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>

#include "hp_common.h"
#include "hp_sys.h"
#include "hp_ipc.h"
#include "hp_vi.h"
static pthread_t gs_IspPid = 0;
static HI_BOOL gbIspInited = HI_FALSE;
static VI_ATTR_S *g_pstViAttr;

/******************************************************************************
* funciton : stop ISP, and stop isp thread
******************************************************************************/
static HI_VOID vdIspStop(VI_ATTR_S * pstViAttr)
{
    ISP_DEV IspDev = pstViAttr->IspDev;

    if (!gbIspInited)
    {
        return;
    }
    
    HI_MPI_ISP_Exit(IspDev);
    if (gs_IspPid)
    {
        pthread_join(gs_IspPid, 0);
        gs_IspPid = 0;
    }
    gbIspInited = HI_FALSE;
    return;
}
static HI_S32 s32StopVi(VI_ATTR_S * pstViAttr)
{
    HI_S32 i;
    HI_S32 s32Ret;
    HI_U32 u32ChnNum;

    if(!pstViAttr)
    {
        printf("%s: null ptr\n", __FUNCTION__);
        return HI_FAILURE;
    }
    
    /*** Stop VI Chn ***/
	u32ChnNum = pstViAttr->u32ChnNum;
    for(i=0;i < u32ChnNum; i++)
    {
        /* Stop vi phy-chn */
        s32Ret = HI_MPI_VI_DisableChn(i);
        if (HI_SUCCESS != s32Ret)
        {
            printf("HI_MPI_VI_DisableChn failed with %#x\n",s32Ret);
            return HI_FAILURE;
        }
    }

    /*** Stop VI Dev ***/
    s32Ret = HI_MPI_VI_DisableDev(pstViAttr->ViDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_DisableDev failed with %#x\n", s32Ret);
        return HI_FAILURE;
    }
    return HI_SUCCESS;
}

static HI_S32 s32StartMIPI(VI_ATTR_S * pstViAttr)
{   
    HI_S32 fd;
	combo_dev_attr_t *pstcomboDevAttr = NULL;

	if (NULL == pstViAttr)
    {
        printf("Func %s() Line[%d], parament is null\n", __FUNCTION__, __LINE__);
        return HI_FAILURE;   
    }
	
	pstcomboDevAttr = pstViAttr->pstcomboDevAttr;
	if (NULL == pstcomboDevAttr)
    {
        printf("Func %s() Line[%d], parament is null\n", __FUNCTION__, __LINE__);
        return HI_FAILURE;   
    }
	
    /* mipi reset unrest */
    fd = open("/dev/hi_mipi", O_RDWR);
    if (fd < 0)
    {
        printf("warning: open hi_mipi dev failed\n");
        return HI_FAILURE;
    }
    if (ioctl(fd, HI_MIPI_SET_DEV_ATTR, pstcomboDevAttr))
    {
        printf("set mipi attr failed\n");
        close(fd);
        return HI_FAILURE;
    }
    close(fd);
    return HI_SUCCESS;
}

static HI_VOID* vdIspRun(HI_VOID *param)
{
    ISP_DEV IspDev = 0;
    HI_MPI_ISP_Run(IspDev);

    return HI_NULL;
}

/******************************************************************************
* funciton : ISP init
******************************************************************************/
static HI_S32 s32IspInit(VI_ATTR_S * pstViAttr)
{
    ISP_DEV IspDev = 0;
    HI_S32 s32Ret;
    ALG_LIB_S stLib;
	ISP_PUB_ATTR_S *pstPubAttr;
	ISP_WDR_MODE_S stWdrMode;
	
	if (NULL == pstViAttr)
    {
        printf("Func %s() Line[%d], parament is null\n", __FUNCTION__, __LINE__);
        return HI_FAILURE;   
    }
	IspDev = pstViAttr->IspDev;
	pstPubAttr = pstViAttr->pstIspPubAttr;
	stWdrMode.enWDRMode = pstViAttr->enWDRMode;
	
    /* 1. sensor register callback */
    s32Ret = sensor_register_callback();
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: sensor_register_callback failed with %#x!\n", \
               __FUNCTION__, s32Ret);
        return s32Ret;
    }

    /* 2. register hisi ae lib */
    stLib.s32Id = 0;
    strcpy(stLib.acLibName, HI_AE_LIB_NAME);
    s32Ret = HI_MPI_AE_Register(IspDev, &stLib);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_AE_Register failed!\n", __FUNCTION__);
        return s32Ret;
    }

    /* 3. register hisi awb lib */
    stLib.s32Id = 0;
    strcpy(stLib.acLibName, HI_AWB_LIB_NAME);
    s32Ret = HI_MPI_AWB_Register(IspDev, &stLib);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_AWB_Register failed!\n", __FUNCTION__);
        return s32Ret;
    }

    /* 4. register hisi af lib */
    stLib.s32Id = 0;
    strcpy(stLib.acLibName, HI_AF_LIB_NAME);
    s32Ret = HI_MPI_AF_Register(IspDev, &stLib);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_AF_Register failed!\n", __FUNCTION__);
        return s32Ret;
    }

    /* 5. isp mem init */
    s32Ret = HI_MPI_ISP_MemInit(IspDev);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_Init failed!\n", __FUNCTION__);
        return s32Ret;
    }

    /* 6. isp set WDR mode */
    s32Ret = HI_MPI_ISP_SetWDRMode(IspDev, &stWdrMode);    
    if (HI_SUCCESS != s32Ret)
    {
        printf("start ISP WDR failed!\n");
        return s32Ret;
    }

    /* 7. isp set pub attributes */
    s32Ret = HI_MPI_ISP_SetPubAttr(IspDev, pstPubAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_SetPubAttr failed with %#x!\n", __FUNCTION__, s32Ret);
        return s32Ret;
    }

    /* 8. isp init */
    s32Ret = HI_MPI_ISP_Init(IspDev);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_Init failed!\n", __FUNCTION__);
        return s32Ret;
    }
	gbIspInited = HI_TRUE;
    /*9. isp run*/
    if (0 != pthread_create(&gs_IspPid, NULL, (void* (*)(void*))vdIspRun, NULL))
    {
        printf("%s: create isp running thread failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }
    usleep(1000);

    return HI_SUCCESS;
}

/*****************************************************************************
* function : star vi dev
*****************************************************************************/
static HI_S32 s32ViStartDev(VI_ATTR_S * pstViAttr)
{
    HI_S32 s32Ret;
    VI_DEV ViDev;
	VI_DEV_ATTR_S * pstViDevAttr;
	VI_DEV_ATTR_EX_S * pstViDevAttrEx;
	if (NULL == pstViAttr)
    {
        printf("Func %s() Line[%d], parament is null\n", __FUNCTION__, __LINE__);
        return HI_FAILURE;   
    }

	ViDev = pstViAttr->ViDev;
	pstViDevAttr = pstViAttr->pstViDevAttr;
	pstViDevAttrEx = pstViAttr->pstViDevAttrEx;
    //s32Ret = HI_MPI_VI_SetDevAttr(ViDev, pstViDevAttr);
	s32Ret = HI_MPI_VI_SetDevAttrEx(ViDev, pstViDevAttrEx);
    if (s32Ret != HI_SUCCESS)
    {
        printf("HI_MPI_VI_SetDevAttr failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }
    
	ISP_WDR_MODE_S stWdrMode;
	s32Ret = HI_MPI_ISP_GetWDRMode(pstViAttr->IspDev, &stWdrMode);
    if (s32Ret != HI_SUCCESS)
    {
        printf("HI_MPI_ISP_GetWDRMode failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }
	if (stWdrMode.enWDRMode)  //wdr mode
    {
        VI_WDR_ATTR_S stWdrAttr;

        stWdrAttr.enWDRMode = stWdrMode.enWDRMode;
        stWdrAttr.bCompress = HI_FALSE;

        s32Ret = HI_MPI_VI_SetWDRAttr(ViDev, &stWdrAttr);
        if (s32Ret)
        {
            printf("HI_MPI_VI_SetWDRAttr failed with %#x!\n", s32Ret);
            return HI_FAILURE;
        }
    }
    
    s32Ret = HI_MPI_VI_EnableDev(ViDev);
    if (s32Ret != HI_SUCCESS)
    {
        printf("HI_MPI_VI_EnableDev failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

	/*Here for 2L1 wdr mode, if not call following func, the vi dev can not receive raw data ,I don't now why..*/
	s32Ret = HI_MPI_VI_EnableBayerDump(ViDev);
	s32Ret = HI_MPI_VI_DisableBayerDump(ViDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableBayerDump failed(0x%x)!\n", s32Ret);
        return s32Ret;
    }
	/*end*/
    return HI_SUCCESS;
}

/*****************************************************************************
* function : star vi chn
*****************************************************************************/
static HI_S32 s32ViStartChn(VI_CHN ViChn, VI_ATTR_S * pstViAttr)
{
    HI_S32 s32Ret;
    VI_CHN_ATTR_S * pstChnAttr;
    
	if (NULL == pstViAttr)
    {
        printf("Func %s() Line[%d], parament is null\n", __FUNCTION__, __LINE__);
        return HI_FAILURE;   
    }

	pstChnAttr = pstViAttr->pstChnAttr;
    s32Ret = HI_MPI_VI_SetChnAttr(ViChn, pstChnAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_EnableChn(ViChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}


static HI_S32 s32StartVi(VI_ATTR_S *pstViAttr)
{
    HI_S32 i, s32Ret = HI_SUCCESS;
    VI_CHN ViChn;
    HI_U32 u32ChnNum;

    if(!pstViAttr)
    {
        printf("%s: null ptr\n", __FUNCTION__);
        return HI_FAILURE;
    }
		
    /******************************************
     step 1: mipi configure
    ******************************************/
    s32Ret = s32StartMIPI(pstViAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: MIPI init failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }     

    /******************************************
     step 2: configure sensor and ISP (include WDR mode).
     note: you can jump over this step, if you do not use interal isp. 
    ******************************************/
    s32Ret = s32IspInit(pstViAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Sensor init failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    /******************************************************
     step 3 : config & start vicap dev
    ******************************************************/
    s32Ret = s32ViStartDev(pstViAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: start vi dev[%d] failed!\n", __FUNCTION__, pstViAttr->ViDev);
        return HI_FAILURE;
    }
    
    /******************************************************
    * Step 4: config & start vicap chn (max 1) 
    ******************************************************/
    u32ChnNum = pstViAttr->u32ChnNum;
    for (i = 0; i < u32ChnNum; i++)
    {
        ViChn = i;
        s32Ret = s32ViStartChn(ViChn,pstViAttr);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: start vi chn[%d] failed!\n", __FUNCTION__, ViChn);
            return HI_FAILURE;
        }
    }

    return s32Ret;
}
combo_dev_attr_t LVDS_4lane_SENSOR_IMX290_10BIT_WDR_ATTR = 
{
    /* input mode */
    .input_mode = INPUT_MODE_LVDS,
    {
        .lvds_attr = {
        .img_size = {1920, 1080},
        HI_WDR_MODE_DOL_2F,
        LVDS_SYNC_MODE_SAV,
        RAW_DATA_10BIT,
        LVDS_ENDIAN_BIG,
        LVDS_ENDIAN_BIG,
        .lane_id = {0, 1, 2, 3, -1, -1, -1, -1},
        .sync_code = { 
                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x100, 0x174}, 
                {0x0AC, 0x0D8, 0x100, 0x174}},
                
                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x100, 0x174}, 
                {0x0AC, 0x0D8, 0x100, 0x174}},

                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x100, 0x174}, 
                {0x0AC, 0x0D8, 0x100, 0x174}},
                
                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x100, 0x174}, 
                {0x0AC, 0x0D8, 0x100, 0x174}},
              /*only 4 ch ,below may be not use*/  
                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}},
                    
                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}},

                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}},
                
                {{0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}, 
                {0x0AC, 0x0D8, 0x001, 0x075}, 
                {0x0AC, 0x0D8, 0x002, 0x076}}, 
            }
        }
    }
};
combo_dev_attr_t LVDS_4lane_SENSOR_IMX290_12BIT_WDR_ATTR = 
{
    /* input mode */
    .input_mode = INPUT_MODE_LVDS,
    {
        .lvds_attr = {
        .img_size = {1920, 1080},
        HI_WDR_MODE_DOL_2F,
        LVDS_SYNC_MODE_SAV,
        RAW_DATA_12BIT,
        LVDS_ENDIAN_BIG,
        LVDS_ENDIAN_BIG,
        .lane_id = {0, 1, 2, 3, -1, -1, -1, -1},
        .sync_code = { 
                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},
                
                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},

                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},
                
                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},
                
                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},
                    
                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},

                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}},
                
                {{0x2b0, 0x360, 0x801, 0x9d1}, 
                {0x2b0, 0x360, 0x802, 0x9d2}, 
                {0x2b0, 0x360, 0x804, 0x9d4}, 
                {0x2b0, 0x360, 0x808, 0x9d8}} 
            }
        }
    }
};

combo_dev_attr_t LVDS_4lane_SENSOR_IMX290_10BIT_NORMAL_ATTR = 
{
    /* input mode */
    .input_mode = INPUT_MODE_LVDS,
    {
        .lvds_attr = {
        .img_size = {1920, 1080},
        HI_WDR_MODE_NONE,
        LVDS_SYNC_MODE_SAV,
        RAW_DATA_10BIT,
        LVDS_ENDIAN_BIG,
        LVDS_ENDIAN_BIG,
        .lane_id = {0, 1, 2, 3, -1, -1, -1, -1},
        .sync_code = { 
                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},
                
                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},

                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},
                
                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},
              /*only 4 ch ,below may be not use*/  
                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},
                
                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},

                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}},
                
                {{0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}, 
                {0x2AC, 0x2D8, 0x200, 0x274}}, 
            }
        }
    }
};
combo_dev_attr_t LVDS_4lane_SENSOR_IMX290_12BIT_NORMAL_ATTR = 
{
    /* input mode */
    .input_mode = INPUT_MODE_LVDS,
    {
        .lvds_attr = {
        .img_size = {1920, 1080},
        HI_WDR_MODE_NONE,
        LVDS_SYNC_MODE_SAV,
        RAW_DATA_12BIT,
        LVDS_ENDIAN_BIG,
        LVDS_ENDIAN_BIG,
        .lane_id = {0, 1, 2, 3, -1, -1, -1, -1},
        .sync_code = { 
                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},
                
                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},

                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},
                
                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},
                
                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},
                    
                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},

                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}},
                
                {{0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}, 
                {0xab0, 0xb60, 0x800, 0x9d0}} 
            }
        }
    }
};

static HI_VOID viAttrInit(const IPC_VEDIO_S* pstIpcVedio,VI_ATTR_S **pstViAttr)
{
	static combo_dev_attr_t MIPI_CMOS3V3_ATTR =
	{
	    /* input mode */
	    
		.input_mode = INPUT_MODE_MIPI,
			{
				.mipi_attr =
				{
					RAW_DATA_12BIT,
					{0, 1, 2, 3, -1, -1, -1, -1}
				}
			}
	    
	};
	static ISP_PUB_ATTR_S ISP_PUB_ATTR =
	{
		.stWndRect = {0, 0, 1920, 1080},
		.f32FrameRate = 30,
		.enBayer = BAYER_GBRG,
	};

	/* the attributes of a VI device */
	static VI_DEV_ATTR_S VI_DEV_ATTR =
	{
	    .enIntfMode = VI_MODE_LVDS,	/* input mode */
	    .enWorkMode = VI_WORK_MODE_1Multiplex,	/*1-, 2-, or 4-channel multiplexed work mode */
	    .au32CompMask = {0xFFC00000,    0x0},	/* r_mask    g_mask    b_mask*/
	    .enScanMode = VI_SCAN_PROGRESSIVE,		/* Input scanning mode (progressive or interlaced) */
	    .s32AdChnId = {-1, -1, -1, -1},			/* AD channel ID. Typically, the default value -1 is recommended */
	    
	    /* The below members must be configured in BT.601 mode or DC mode and are invalid in other modes */
	    .enDataSeq = VI_INPUT_DATA_YUYV,		/* Input data sequence (only the YUV format is supported) */
	    .stSynCfg =
	    {
			VI_VSYNC_PULSE, 		/*Vsync*/
			VI_VSYNC_NEG_LOW, 		/*VsyncNeg*/
			VI_HSYNC_VALID_SINGNAL,			/*Hsync*/
			VI_HSYNC_NEG_HIGH,		/*HsyncNeg*/
			VI_VSYNC_VALID_SINGAL,	/*VsyncValid*/
			VI_VSYNC_VALID_NEG_HIGH,/*VsyncValidNeg*/
			/*The below TimingBlank only for BT.601*/
		    /*hsync_hfb    hsync_act    hsync_hhb*/
		    {0,            1920,        0,
		    /*vsync0_vhb vsync0_act vsync0_hhb*/
		     0,            1080,        0,
		    /*vsync1_vhb vsync1_act vsync1_hhb*/
		     0,            0,            0}
		},
	    .enDataPath = VI_PATH_ISP,			/* ISP enable or bypass */
	    .enInputDataType = VI_DATA_TYPE_RGB,/* RGB: CSC-709 or CSC-601, PT YUV444 disable; YUV: default yuv CSC coef PT YUV444 enable. */
	    .bDataRev = HI_FALSE,				/* Data Reverse */
	    .stDevRect = {0, 30, 1920, 1080}		/* Dev capture rect */
	};

	static VI_DEV_ATTR_EX_S VI_DEV_ATTR_EX =
	{
	    .enInputMode = VI_INPUT_MODE_LVDS,	/* Interface mode */
	    .enWorkMode = VI_WORK_MODE_1Multiplex,	/*1-, 2-, or 4-channel multiplexed work mode */
		.enCombineMode = VI_COMBINE_COMPOSITE,	/* Y/C composite or separation mode */
		.enCompMode = VI_COMP_MODE_SINGLE, 		/* Component mode (single-component or dual-component) */
		.enClkEdge = VI_CLK_EDGE_SINGLE_DOWN,	/* Clock edge mode (sampling on the rising or falling edge) */

	    .au32CompMask = {0xFFC00000,    0x0},	/* r_mask    g_mask    b_mask*/
	    .enScanMode = VI_SCAN_PROGRESSIVE,		/* Input scanning mode (progressive or interlaced) */
	    .s32AdChnId = {-1, -1, -1, -1},			/* AD channel ID. Typically, the default value -1 is recommended */
	    
	    /* The below members must be configured in BT.601 mode or DC mode and are invalid in other modes */
	    .enDataSeq = VI_INPUT_DATA_YUYV,		/* Input data sequence (only the YUV format is supported) */
	    .stSynCfg =
	    {
			VI_VSYNC_PULSE, 		/*Vsync*/
			VI_VSYNC_NEG_LOW, 		/*VsyncNeg*/
			VI_HSYNC_VALID_SINGNAL,			/*Hsync*/
			VI_HSYNC_NEG_HIGH,		/*HsyncNeg*/
			VI_VSYNC_VALID_SINGAL,	/*VsyncValid*/
			VI_VSYNC_VALID_NEG_HIGH,/*VsyncValidNeg*/
			/*The below TimingBlank only for BT.601*/
		    /*hsync_hfb    hsync_act    hsync_hhb*/
		    {0,            1920,        0,
		    /*vsync0_vhb vsync0_act vsync0_hhb*/
		     0,            1080,        0,
		    /*vsync1_vhb vsync1_act vsync1_hhb*/
		     0,            0,            0}
		},
		.stBT656SynCfg = {BT656_FIXCODE_1,BT656_FIELD_POLAR_STD},      /* Sync timing. This member must be configured in BT.656 mode */
	    .enDataPath = VI_PATH_ISP,			/* ISP enable or bypass */
	    .enInputDataType = VI_DATA_TYPE_RGB,/* RGB: CSC-709 or CSC-601, PT YUV444 disable; YUV: default yuv CSC coef PT YUV444 enable. */
	    .bDataRev = HI_FALSE,				/* Data Reverse */
	    .stDevRect = {0, 30, 1920, 1080}		/* Dev capture rect */
	};
	
	/* the attributes of a VI channel */
	static VI_CHN_ATTR_S VI_CHN_ATTR = 
	{
		.stCapRect = {0, 0, 1920, 1080},
		.stDestSize	= {1920, 1080},
		.enCapSel = VI_CAPSEL_BOTH,
		.enPixFormat = PIXEL_FORMAT_YUV_SEMIPLANAR_420,
		.enCompressMode = COMPRESS_MODE_NONE,
		.bMirror = HI_FALSE,
		.bFlip = HI_FALSE,
		.s32SrcFrameRate = -1,
		.s32DstFrameRate = -1
	};

	static VI_ATTR_S VI_ATTR = 
	{
		.IspDev = 0,
		.ViDev = 0,
		.u32ChnNum = 1,
		.enWDRMode = WDR_MODE_NONE,
		.pstcomboDevAttr = &LVDS_4lane_SENSOR_IMX290_10BIT_WDR_ATTR,
		.pstIspPubAttr = &ISP_PUB_ATTR,
		.pstViDevAttr = &VI_DEV_ATTR,
		.pstViDevAttrEx = &VI_DEV_ATTR_EX,
		.pstChnAttr = &VI_CHN_ATTR
	};
	/*sync isp pub attr*/
	
	VI_ATTR.pstIspPubAttr->stWndRect.u32Width = pstIpcVedio->astStreamFmt[0].stSize.u32Width;
	VI_ATTR.pstIspPubAttr->stWndRect.u32Height = pstIpcVedio->astStreamFmt[0].stSize.u32Height;
	VI_ATTR.pstIspPubAttr->f32FrameRate = pstIpcVedio->astStreamFmt[0].f32FrameRate;
	/*sync vi dev attr*/
	VI_ATTR.pstViDevAttr->stDevRect.u32Width = pstIpcVedio->astStreamFmt[0].stSize.u32Width;
	VI_ATTR.pstViDevAttr->stDevRect.u32Height = pstIpcVedio->astStreamFmt[0].stSize.u32Height;

	//VI_ATTR.pstViDevAttrEx->stDevRect.u32Width = pstIpcVedio->astStreamFmt[0].stSize.u32Width;
	//VI_ATTR.pstViDevAttrEx->stDevRect.u32Height = pstIpcVedio->astStreamFmt[0].stSize.u32Height;
	/*sync vi chn attr*/
	VI_ATTR.pstChnAttr->stCapRect.s32X = (1920-pstIpcVedio->astStreamFmt[0].stSize.u32Width)/2;
	VI_ATTR.pstChnAttr->stCapRect.s32Y = (1080-pstIpcVedio->astStreamFmt[0].stSize.u32Height)/2;
	VI_ATTR.pstChnAttr->stCapRect.u32Width = pstIpcVedio->astStreamFmt[0].stSize.u32Width;
	VI_ATTR.pstChnAttr->stCapRect.u32Height = pstIpcVedio->astStreamFmt[0].stSize.u32Height;
	VI_ATTR.pstChnAttr->stDestSize.u32Width = pstIpcVedio->astStreamFmt[0].stSize.u32Width;
	VI_ATTR.pstChnAttr->stDestSize.u32Height = pstIpcVedio->astStreamFmt[0].stSize.u32Height;
	VI_ATTR.pstChnAttr->enPixFormat = pstIpcVedio->e_pixFmt;
	/*sync wdr mode*/
	VI_ATTR.enWDRMode = pstIpcVedio->e_wdrMode;
	
	*pstViAttr = &VI_ATTR;
}
HI_S32 VI_init(const IPC_VEDIO_S* pstIpcVedio)
{
	HI_S32 s32Ret = HI_SUCCESS;
	if(!pstIpcVedio)
    {
        printf("%s: null ptr\n", __FUNCTION__);
        return HI_FAILURE;
    }
	viAttrInit(pstIpcVedio,&g_pstViAttr);
	s32Ret = s32StartVi(g_pstViAttr);
	return s32Ret;
}

HI_S32 VI_exit(void)
{
	HI_S32 s32Ret = HI_SUCCESS;
	s32Ret = s32StopVi(g_pstViAttr);
	vdIspStop(g_pstViAttr);
	return s32Ret;
}

